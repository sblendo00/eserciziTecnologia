package mypkg;
 
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
 
public class PrenotaColloquio extends HttpServlet {
   @Override
   public void doGet(HttpServletRequest request, HttpServletResponse response)
               throws IOException, ServletException {
      // Set the response message's MIME type
      response.setContentType("text/html;charset=UTF-8");
      // Allocate a output writer to write the response message into the network socket
      PrintWriter out = response.getWriter();
 
      // Write the response message, in an HTML page
         try {
         out.println("<!DOCTYPE html>");
         out.println("<html><head>");
         out.println("<meta http-equiv=/Content-Type content=/text/html; charset=UTF-8'>");
         out.println("<title>Prenota Colloquio</title></head>");
         out.println("<body><h1>PRENOTA COLLOQUIO</h1>");
         
         String cognome = request.getParameter("cognome");
         if(cognome == ""){
             out.println("<p>INSERISCI IL COGNOME!</p>");
             }
             else{
                 out.println("<p>Benvenuto " + cognome + "</p>");
         }
         
         String classe = request.getParameter("classe");
         if(classe == "vuoto"){
             out.println("<p>SELEZIONA LA CLASSE</p>");
             }
             else{
                 out.println("Sei della " + classe);
                 }
                 
        String compiti = request.getParameter("compiti");
        if(compiti == null){
            out.println("<p>DEFINISCI SE VUOI VISUALIZZARE I COMPITI DELLO STUDENTE</p>");
            }
            else if(compiti == "si"){
                out.println("<p>Hai scelto di visualizzare i compiti dello studente</p>");
                }
                else{
                    out.println("<p>Hai scelto di non visualizzare i compiti dello studente</p>");
                    }
                        
        String docente = request.getParameter("docente");
        if(docente == null){
            out.println("<p>Hai scelto di non fissare il colloquio");
            }
            else{
                out.println("<p>Hai fissato il colloquio con " + docente);
                }
      } finally {
         out.close();  // Always close the output writer
      }
   }
}