package mypkg;
 
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
 
public class  GestioneAppuntamenti extends HttpServlet {
   @Override
   public void doGet(HttpServletRequest request, HttpServletResponse response)
               throws IOException, ServletException {
      // Set the response message's MIME type
      response.setContentType("text/html;charset=UTF-8");
      // Allocate a output writer to write the response message into the network socket
      PrintWriter out = response.getWriter();
 
      // Write the response message, in an HTML page
      try {
         out.println("<!DOCTYPE html>");
         out.println("<html>");
         out.println("<head>");
         out.println("<meta http-equiv='Content-Type' content='text/html'; charset='UTF-8'>");
         out.println("<title>Credenziali</title>");
         out.println("</head>");
         out.println("<body>");
         out.println("<h1>Inserisci le tue credenziali</h1>");
         out.println("<form method='get' action='prenotaColloquio'>");
         out.println("<fieldset>");
         out.println("<legend>Dati personali</legend>");

         out.println("Cognome: <input type='text' name='cognome' /><br /><br />");

         out.println("Classe: <form action='/action_page.php'>");
         out.println("<select name='classe'>");
         out.println("<option value='4EInf'>4E inf</option>");
         out.println("<option value='vuoto' selected>-</option>");
         out.println("</select>");
         out.println("<br><br>");
         out.println("</form>");
  
         out.println("Compiti: <p>Desideri visualizzare i compiti dello studente?</p>");
         out.println("<form>");
         out.println("<input type='radio' name='compiti' value='vuoto' checked> -<br>");
         out.println("<input type='radio' name='compiti' value='si'> SI<br>");
         out.println("<input type='radio' name='compiti' value='no'> NO<br>");
         out.println("</form>");

         out.println("Docenti: <p>Desideri fissare un colloquio con i docenti?(mantieni ctrl + click stx per selezionare più di un docente)</p>");
         out.println("<form action='/action_page.php'>");
         out.println("<select name='docente' size='8' multiple>");
         out.println("<option value='Giraldi'>Prof.ssa Giraldi</option>");
         out.println("<option value='Malizia'>Prof. Malizia</option>");
         out.println("<option value='Bellocco'>Prof.ssa Bellocco</option>");
         out.println("<option value='Spadoni'>Prof. Spadoni</option>");
         out.println("<option value='Arcostanzo'>Prof. Arcostanzo</option>");
         out.println("<option value='Titze'>Prof. Titze</option>");
         out.println("<option value='Carrara'>Prof.ssa Carrara</option>");
         out.println("<option value='Apicella'>Prof.ssa Apicella</option>");
         out.println("</select>");
         out.println("<br><br>");
         out.println("</form>");
         out.println("<input type='submit' value='SEND' />");
         out.println("<input type='reset' value='CLEAR' />");
         out.println("</fieldset>");
         out.println("</form>");
         out.println("</body>");
         out.println("</html>");
      } finally {
         out.close();  // Always close the output writer
      }
   }
}